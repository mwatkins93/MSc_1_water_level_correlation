####-------------------------
## Matt Watkins
## Date: Nov. 15th/21
## Project: Water depth QA/QC v1.02
## Objective: To prepare a continous water level at a corrected daturm for each site!
## Inputs: rebar_waterdepth.RDS
## Outputs: (1) corrected graphs for each site; (2) diagnostic graphs for each site
####-------------------------

## Prepare
##---------------------------

library(tidyverse)
library(dygraphs)
library(plotly)
library(lubridate)
library(readxl)

options(scipen = 999)

## Import
##---------------------------

water_depth <- readRDS("rebar_waterdepth.RDS") ## corrected water depth

ssm_precip <- read_csv("May_to_Oct Precipitation.csv") ## precip

## Tidy / Process
##---------------------------

##. 0.0 Start with WS44 - rebar looks okay (within 3.4cm for all bed to top measurements - most likely due to inconsistent tape stake depth in channel bed beside rebar or sediment movement)
##--------------------------------------------

ws44_dat <- water_depth %>% 
  filter(water.loggerID %in% "20484018") ## start with ws44

ws44_datum <- ws44_dat %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average)

ws44_out <- ws44_datum %>% 
  mutate(water.metres = water.depth * (1000 / 9806.65)) # Convert water depth (kPa) to metres to match rebar units = 1000kPa:1kPa; 1mH20:9806.65Pal thus, kPa = 1000Pa / 9806.65 gets metres.

## 0.1 Start removing the easy data (pre-installation and post-removal)
##---------------------------------------------------------------------

is.na(ws44_out$`water.metres`) <- ws44_out$time < "2021-05-31 12:00:00" ## logger installed at 12:15 on May 31st - every value before 12PM on that date set to NA.

is.na(ws44_out$`water.metres`) <- ws44_out$time >= "2021-10-24 12:00:00" ## everything from this hour onward includes post-removal

## 0.2 Adjust water level to rebar datum
##--------------------------------------

## Reinstall offset 1: June 13th 1PM  to > Aug. 11th 1PM

ws44_out$water.metres[407:1822] <- ws44_out$water.metres[407:1822] + 0.0504468 # increase to match (difference between the averaged water level the hour prior to reinstalling and the new water level after reinstalling logger)

## Reinstall offset 2: >= Aug 11th 1PM - <= Oct. 24th 11AM

ws44_out$water.metres[1823:3597] <- ws44_out$water.metres[1823:3597] + .1330608 ## increase to match - WS 44 is done now

## 1. Continue process for all remaining watersheds
##-------------------------------------------------

## WS 96
##------

ws96_dat <- water_depth %>% 
  filter(water.loggerID %in% "20996923") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws96_dat$`water.metres`) <- ws96_dat$time <= "2021-06-04 11:00:00" # prior to installation

is.na(ws96_dat$`water.metres`) <- ws96_dat$time >= "2021-10-26 10:00:00" # post removal

is.na(ws96_dat$`water.metres`) <- ws96_dat$time == "2021-06-16 10:00:00" # this weird hourly drop probably includes measurements taken out of water - removed

is.na(ws96_dat$`water.metres`) <- ws96_dat$time == "2021-08-12 10:00:00" # 5cm drop in water level right at the time of retrieval/reinstall, probably a measurement averaged within the hour out of the water - removed

## Reinstall offset 1: June 16th 11AM to > Aug. 12th 10AM

ws96_dat$water.metres[330:1697] <- ws96_dat$water.metres[330:1697] - .0086166 # decrease to match

## Reinstall offset 2:

ws96_dat$water.metres[1698:3496] <- ws96_dat$water.metres[1698:3496] - .05703612 # decrease to match - WS 96 done

## WS 93
##------

# Moved logger here, will return.


## WS 92
##------

# Moved logger here, will return.

## WS 82
##------

ws82_dat <- water_depth %>% 
  filter(water.loggerID %in% "20996924") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws82_dat$`water.metres`) <- ws82_dat$time < "2021-06-04 09:00:00" # prior to install

is.na(ws82_dat$`water.metres`) <- ws82_dat$time > "2021-10-25 14:00:00" # post removal

is.na(ws82_dat$`water.metres`) <- ws82_dat$time == "2021-06-15 17:00:00" # 8cm jump, but not equivalent to new install position of 11cm = out of water averaged in - removed

## Reinstall offset #1:

ws82_dat$water.metres[313:1696] <- ws82_dat$water.metres[313:1696] - .03991704 # decrease to match

## Reinstall offset #2:

ws82_dat$water.metres[1697:3477] <- ws82_dat$water.metres[1697:3477] - .05708227 # decrease to match - WS 82 is done

## WS 87
##------

ws87_dat <- water_depth %>% 
  filter(water.loggerID %in% "20833386") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws87_dat$`water.metres`) <- ws87_dat$time < "2021-06-04 08:00:00" # prior to install

is.na(ws87_dat$`water.metres`) <- ws87_dat$time > "2021-10-25 14:00:00" # post removal

is.na(ws87_dat$`water.metres`) <- ws87_dat$time == "2021-06-15 16:00:00" # 10cm drop probably includes out of water data in the average - removed

## Reinstall offset #1:

ws87_dat$water.metres[312:1696] <- ws87_dat$water.metres[312:1696] - .00370497 # decrease to match

## Reinstall offset #2:

ws87_dat$water.metres[1697:3477] <- ws87_dat$water.metres[1697:3477] - .01845687 # decrease to match - prior to completing offset #1, at time "2021-08-12 09:00:00", there was a 3mm offset, but I left it in due to how small it was...

## WS 84
##------

ws84_dat <- water_depth %>% 
  filter(water.loggerID %in% "20879408") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws84_dat$`water.metres`) <- ws84_dat$time < "2021-06-03 19:00:00" # prior to install

is.na(ws84_dat$`water.metres`) <- ws84_dat$time > "2021-10-25 13:00:00" # post removal

is.na(ws84_dat$`water.metres`) <- ws84_dat$time == "2021-06-15 15:00:00" # > than a 1cm offset here - contains out of water averages - removed

is.na(ws84_dat$`water.metres`) <- ws84_dat$time == "2021-08-12 09:00:00" # > than a 1cm offset here - contains out of water averages - removed

## Reinstall offset #1:

ws84_dat$water.metres[311:1695] <- ws84_dat$water.metres[311:1695] - .0035894 # decrease to match

## Reinstall offset #2:

ws84_dat$water.metres[1697:3476] <- ws84_dat$water.metres[1697:3476] - .02372879 # decrease to match

## WS 110
##-------

ws110_dat <- water_depth %>% 
  filter(water.loggerID %in% "20958989") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws110_dat$`water.metres`) <- ws110_dat$time < "2021-06-03 17:00:00" # prior to install

is.na(ws110_dat$`water.metres`) <- ws110_dat$time > "2021-10-25 13:00:00" # post removal

is.na(ws110_dat$`water.metres`) <- ws110_dat$time == "2021-06-15 14:00:00" # 2.9 cm offset right before time of reinstall - removed

## Reinstall offset #1:

ws110_dat$water.metres[310:1695] <- ws110_dat$water.metres[310:1695] - .09495743 # decrease to match

## Reinstall offset #2:

ws110_dat$water.metres[1696:3476] <- ws110_dat$water.metres[1696:3476] - .10567805 # decrease to match

## It is corrected, but the correction falls into the negative water depth - what does this mean? Is that time the logger was out of the water?

## WS 76/77
##---------

ws77_dat <- water_depth %>% 
  filter(water.loggerID %in% "20996915") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

## Skipped for now - somehow there is missing data from June 3rd to June 16th. Also, data is extremely noisy.

## WS 75
##------

ws75_dat <- water_depth %>% 
  filter(water.loggerID %in% "20958988") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws75_dat$`water.metres`) <- ws75_dat$time < "2021-06-03 16:00:00" # prior to install

is.na(ws75_dat$`water.metres`) <- ws75_dat$time > "2021-10-25 11:00:00" # post removal

is.na(ws75_dat$`water.metres`) <- ws75_dat$time == "2021-06-15 13:00:00" # 2cm offset at time of arrival/reinstall so it has out of water influence - removed

is.na(ws75_dat$`water.metres`) <- ws75_dat$time == "2021-08-12 08:00:00" # 5cm drop at time of arrival/reinstall so - removed

## Reinstall offset #1:

ws75_dat$water.metres[309:1694] <- ws75_dat$water.metres[309:1694] + .0589518 # increase to match (less than 5mm difference, I could probably revert it and leave it alone)

## Reinstall offset #2:

ws75_dat$water.metres[1696:3474] <- ws75_dat$water.metres[1696:3474] + .0634556 # increase to match

## WS 73
##------

# Moved logger here, will return.

## WS BL1
##-------

wsBL1_dat <- water_depth %>% 
  filter(water.loggerID %in% "20959000") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(wsBL1_dat$`water.metres`) <- wsBL1_dat$time < "2021-06-03 12:00:00" # prior to install

is.na(wsBL1_dat$`water.metres`) <- wsBL1_dat$time > "2021-10-25 09:00:00" # post removal

is.na(wsBL1_dat$`water.metres`) <- wsBL1_dat$time == "2021-06-15 09:00:00" # includes time out of water - removed

## Reinstall offset #1:

wsBL1_dat$water.metres[305:1678] <- wsBL1_dat$water.metres[305:1678] - .02307966 # deccrease to match

## Reinstall offset #2:

wsBL1_dat$water.metres[1679:3472] <- wsBL1_dat$water.metres[1679:3472] - .01009187 # decrease to match (arrival/reinstall is very close ~4mm so I'm leaving that data point in)

## WS BL2
##-------

wsBL2_dat <- water_depth %>% 
  filter(water.loggerID %in% "20833388") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(wsBL2_dat$`water.metres`) <- wsBL2_dat$time < "2021-06-03 13:00:00" # prior to install

is.na(wsBL2_dat$`water.metres`) <- wsBL2_dat$time > "2021-10-25 10:00:00" # post removal

is.na(wsBL2_dat$`water.metres`) <- wsBL2_dat$time == "2021-06-15 10:00:00" # 2+cm offset at arrival/reinstall hour (contains out of water time) - removed

is.na(wsBL2_dat$`water.metres`) <- wsBL2_dat$time == "2021-08-11 15:00:00" ## contains out of water time - removed

## Reinstall offset #1:

wsBL2_dat$water.metres[306:1677] <- wsBL2_dat$water.metres[306:1677] - .0116247 # deccrease to match

## Reinstall offset #2:

wsBL2_dat$water.metres[1679:3473] <- wsBL2_dat$water.metres[1679:3473] - .04097553 # decrease to match

## WS 67
##------

# Moved logger here, will return.

## WS 66
##------

ws66_dat <- water_depth %>% 
  filter(water.loggerID %in% "20879414") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws66_dat$`water.metres`) <- ws66_dat$time < "2021-06-03 10:00:00" # prior to install

is.na(ws66_dat$`water.metres`) <- ws66_dat$time > "2021-10-24 08:00:00" # post removal

is.na(ws66_dat$`water.metres`) <- ws66_dat$time == "2021-06-13 08:00:00" # 10cm drop contains out of water - removed

is.na(ws66_dat$`water.metres`) <- ws66_dat$time == "2021-08-11 14:00:00" # ~1cm increase (out of water mixed in) - removed for now, can always revert

## Reinstall offset #1:

ws66_dat$water.metres[329:1750] <- ws66_dat$water.metres[329:1750] + .1167648 # increase to match

## Reinstall offset #2:

ws66_dat$water.metres[1751:3520] <- ws66_dat$water.metres[1751:3520] + .0204187 # increase to match

## WS 36
##------

ws36_dat <- water_depth %>% 
  filter(water.loggerID %in% "20996920") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws36_dat$`water.metres`) <- ws36_dat$time < "2021-05-31 17:00:00" # prior to install

is.na(ws36_dat$`water.metres`) <- ws36_dat$time > "2021-10-24 08:00:00" # post removal

is.na(ws36_dat$`water.metres`) <- ws36_dat$time == "2021-06-13 10:00:00" # ~2cm adjustment at time of arrival/reinstall - removed

## For Aug. 11th, values are very close - no row to remove near reinstall time

## Reinstall offset #1:

ws36_dat$water.metres[331:1750] <- ws36_dat$water.metres[331:1750] - .0121653 # decrease to match

## Reinstall offset #2:

ws36_dat$water.metres[1751:3520] <- ws36_dat$water.metres[1751:3520] + .0047416 # increase to match

## WS 40
##------

ws40_dat <- water_depth %>% 
  filter(water.loggerID %in% "20440923") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws40_dat$`water.metres`) <- ws40_dat$time < "2021-05-31 15:00:00" # prior to install

is.na(ws40_dat$`water.metres`) <- ws40_dat$time > "2021-10-24 09:00:00" # post removal

is.na(ws40_dat$`water.metres`) <- ws40_dat$time == "2021-06-13 11:00:00" # 3+ cm jump here at arrival - removed

is.na(ws40_dat$`water.metres`) <- ws40_dat$time == "2021-08-11 14:00:00"

is.na(ws40_dat$`water.metres`) <- ws40_dat$time == "2021-08-11 15:00:00" # this is strange, two 1.5cm drops over 2 hours near reinstall - removing for now

## Reinstall offset #1:

ws40_dat$water.metres[405:1822] <- ws40_dat$water.metres[405:1822] - .06290193 # decrease to match

## Reinstall offset #2:

ws40_dat$water.metres[1825:3594] <- ws40_dat$water.metres[1825:3594] - .07291214 # decrease to match

## WS 43
##------

ws43_dat <- water_depth %>% 
  filter(water.loggerID %in% "20440889") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws43_dat$`water.metres`) <- ws43_dat$time < "2021-05-31 16:00:00" # prior to install - a few stabilisation hourly measurement, but one contains a rise of 8cm which is inconsistent with the rest of the water level. Removed from this point backward for now.

is.na(ws43_dat$`water.metres`) <- ws43_dat$time > "2021-10-24 11:00:00" # post removal

is.na(ws43_dat$`water.metres`) <- ws43_dat$time == "2021-08-11 13:00:00" # 3cm drop near arrival/reinstall - removed

## Reinstall offset #1:

ws43_dat$water.metres[406:1822] <- ws43_dat$water.metres[406:1822] + .0686779 # increase to match - levels around arrival look fine here

## Reinstall offset #2:

ws43_dat$water.metres[1824:3597] <- ws43_dat$water.metres[1824:3597] - .0027872 # decrease to match

## WS 45
##------

ws45_dat <- water_depth %>% 
  filter(water.loggerID %in% "20440766") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws45_dat$`water.metres`) <- ws45_dat$time < "2021-05-31 10:00:00" # prior to install

is.na(ws45_dat$`water.metres`) <- ws45_dat$time > "2021-10-24 11:00:00" # post removal

is.na(ws45_dat$`water.metres`) <- ws45_dat$time == "2021-06-13 14:00:00" # major drop at time of arrival - removed

is.na(ws45_dat$`water.metres`) <- ws45_dat$time == "2021-08-11 12:00:00" # 3cm drop at time of arrival - removed

## Reinstall offset #1:

ws45_dat$water.metres[409:1821] <- ws45_dat$water.metres[409:1821] - .0237934 # decrease to match

## Reinstall offset #2:

ws45_dat$water.metres[1823:3597] <- ws45_dat$water.metres[1823:3597] + .0427261 # increase to match

## WS 46
##------

ws46_dat <- water_depth %>% 
  filter(water.loggerID %in% "20525616") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws46_dat$`water.metres`) <- ws46_dat$time < "2021-05-31 10:00:00" # prior to install

is.na(ws46_dat$`water.metres`) <- ws46_dat$time > "2021-10-23 16:00:00" # post removal

is.na(ws46_dat$`water.metres`) <- ws46_dat$time == "2021-06-12 16:00:00" # drop at arrival - removed

## For Aug. 11th, values are very close - no row to remove near reinstall time

## Reinstall offset #1:

ws46_dat$water.metres[387:1821] <- ws46_dat$water.metres[387:1821] - .0475188 # decrease to match

## Reinstall offset #2:

ws46_dat$water.metres[1822:3578] <- ws46_dat$water.metres[1822:3578] - .0376343 # decrease to match

## WS 47
##------

ws47_dat <- water_depth %>% 
  filter(water.loggerID %in% "20525614") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws47_dat$`water.metres`) <- ws47_dat$time < "2021-05-28 17:00:00" # prior to install

is.na(ws47_dat$`water.metres`) <- ws47_dat$time > "2021-10-23 15:00:00" # post removal

is.na(ws47_dat$`water.metres`) <- ws47_dat$time == "2021-06-12 15:00:00" # arrival/out of water drop - removed

is.na(ws47_dat$`water.metres`) <- ws47_dat$time == "2021-08-11 11:00:00" # 1.5cm drop at arrival time - removed

## Reinstall offset #1:

ws47_dat$water.metres[386:1820] <- ws47_dat$water.metres[386:1820] + .0018185 # increase to match

## Reinstall offset #2:

ws47_dat$water.metres[1822:3577] <- ws47_dat$water.metres[1822:3577] - .0303195 # decrease to match

## WS 52
##------

ws52_dat <- water_depth %>% 
  filter(water.loggerID %in% "20402298") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws52_dat$`water.metres`) <- ws52_dat$time < "2021-05-28 16:00:00" # prior to install

is.na(ws52_dat$`water.metres`) <- ws52_dat$time > "2021-10-23 14:00:00" # post removal

## June 12th - only 3mm offset at time of arrival so keeping that hour of data for now

## Aug. 11th - just adjusting, no removing. Significant rises/drops (i.e., 3-8cm) in stream level throughout the dataset so

## Reinstall offset #1:

ws52_dat$water.metres[384:1820] <- ws52_dat$water.metres[384:1820] + .01390699 # increase to match

## Reinstall offset #2:

ws52_dat$water.metres[1821:3576] <- ws52_dat$water.metres[1821:3576] - .01552882 # decrease to match

## WS 54
##------

ws54_dat <- water_depth %>% 
  filter(water.loggerID %in% "20715030") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(ws54_dat$`water.metres`) <- ws54_dat$time < "2021-05-28 15:00:00" # prior to install

is.na(ws54_dat$`water.metres`) <- ws54_dat$time > "2021-10-23 13:00:00" # post removal

is.na(ws54_dat$`water.metres`) <- ws54_dat$time == "2021-06-12 13:00:00" # resetting/adjusting after arrival - removed

is.na(ws54_dat$`water.metres`) <- ws54_dat$time == "2021-08-11 10:00:00" # arrival discrepancy here - removed

## Reinstall offset #1:

ws54_dat$water.metres[384:1819] <- ws54_dat$water.metres[384:1819] - .1055914 # decrease to match

## Reinstall offset #2:

ws54_dat$water.metres[1821:3575] <- ws54_dat$water.metres[1821:3575] - .09932014 # decrease to match

## WS SSR
##------

wsSSR_dat <- water_depth %>% 
  filter(water.loggerID %in% "20715043") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(wsSSR_dat$`water.metres`) <- wsSSR_dat$time < "2021-05-28 12:00:00" # prior to install

is.na(wsSSR_dat$`water.metres`) <- wsSSR_dat$time > "2021-10-23 11:00:00" # post removal

is.na(wsSSR_dat$`water.metres`) <- wsSSR_dat$time == "2021-06-12 11:00:00" # restabilisation data point at arrival - removed

is.na(wsSSR_dat$`water.metres`) <- wsSSR_dat$time == "2021-08-11 09:00:00" # 3cm drop at arrival/reinstall - removed

## Reinstall offset #1:

wsSSR_dat$water.metres[384:1818] <- wsSSR_dat$water.metres[384:1818] + .1467372 # increase to match

## Reinstall offset #2:

wsSSR_dat$water.metres[1820:3573] <- wsSSR_dat$water.metres[1820:3573] + .2376109 # increase to match

## WS SBC
##-------

wsSBC_dat <- water_depth %>% 
  filter(water.loggerID %in% "20440791") %>% 
  mutate(rebar.datum = top.to.bed.average - top.to.surface.average,
         water.metres = water.depth * (1000 / 9806.65))

is.na(wsSBC_dat$`water.metres`) <- wsSBC_dat$time < "2021-05-28 10:00:00" # prior to install - 4mm change at Q estimate point to next hourly point, leaving it for now.

is.na(wsSBC_dat$`water.metres`) <- wsSBC_dat$time > "2021-10-23 11:00:00" # post removal

is.na(wsSBC_dat$`water.metres`) <- wsSBC_dat$time == "2021-06-12 10:00:00" # 1.1cm adjustment at arrival time - removed

is.na(wsSBC_dat$`water.metres`) <- wsSBC_dat$time == "2021-08-11 09:00:00" # 3cm adjustment at data collection time - removed

## Also on Aug. 11th, about 8hrs after reinstall there is a 5cm jump in water level with frequent jumps up and down shortly afterwards (Lines 1828-1835). Interesting dynamics.

## Reinstall offset #1:

wsSBC_dat$water.metres[381:1818] <- wsSBC_dat$water.metres[381:1818] - .0160605 # decrease to match

## Reinstall offset #2:

wsSBC_dat$water.metres[1820:3573] <- wsSBC_dat$water.metres[1820:3573] - .02858607 # decrease to match

##---------------------------

## Take a look at an interactive plot

wsSBC_dat %>%
plot_ly(x = ~time, y = ~water.metres)

## Take a look at precipitation quickly

ssm_precip %>%
  plot_ly(x = ~`Date/Time (UTC)`, y = ~`Precip. Amount (mm)`)
    
## Saving / Exporting
##---------------------------

## Notes / Junk Code
##---------------------------
